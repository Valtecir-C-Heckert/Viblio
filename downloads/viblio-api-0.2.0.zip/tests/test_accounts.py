import copy,concurrent.futures,gzip,json,uuid
import pytest
from fastapi.testclient import TestClient
from app.main import create_app
from app.personal_library import merge_snapshot,compact
from test_api import DSN,TOKEN,AUTH
@pytest.fixture
def api(tmp_path):
    with TestClient(create_app(DSN,TOKEN,tmp_path,'http://localhost:8088')) as client:yield client
def headers(user):return {'Authorization':'Bearer '+user['token']}
def admin(api):
    body=dict(email='admin@example.test',password='test-password-123456')
    r=api.post('/v1/auth/bootstrap',headers=AUTH,json=body)
    if r.status_code==409:r=api.post('/v1/auth/login',json=body)
    assert r.status_code==200,r.text
    return r.json()
def invited(api,owner):
    code=api.post('/v1/admin/invitations',headers=headers(owner),json={}).json()['code']
    r=api.post('/v1/auth/register',json=dict(email=uuid.uuid4().hex+'@example.test',password='guest-password-123456',invitation=code))
    assert r.status_code==200,r.text
    return r.json()
def snapshot():return {'library':{'schemaVersion':6,'currentBookId':'book','books':[dict(id='book',kind='book',title='Livro',author='Autor',totalPages=100,currentPage=0,coverData='',rating=None,archived=False)],'collections':[],'sessions':[],'readingDates':[]},'appearance':{'SHELF_MANUAL_ORDER:book':'["book"]'}}
def sync(api,user,data,base=0,**kwargs):
    identifier=kwargs.pop("request_id",str(uuid.uuid4()))
    raw=gzip.compress(json.dumps(dict(request_id=identifier,base_revision=base,snapshot=data,**kwargs)).encode())
    return api.post('/v1/me/library/sync',headers=headers(user),content=raw)
def result(r):
    assert r.status_code==200,r.text
    return json.loads(gzip.decompress(r.content))
def test_bootstrap_and_single_use_invitation(api):
    owner=admin(api)
    assert api.post('/v1/auth/bootstrap',headers=AUTH,json=dict(email='other@example.test',password='password-123456')).status_code==409
    assert api.post('/v1/auth/register',json=dict(email='a@example.test',password='password-123456')).status_code==422
    invite=api.post('/v1/admin/invitations',headers=headers(owner),json={}).json()
    body=dict(email=uuid.uuid4().hex+'@example.test',password='password-123456',invitation=invite['code'])
    with concurrent.futures.ThreadPoolExecutor(2) as pool:codes=list(pool.map(lambda _:api.post('/v1/auth/register',json=body).status_code,range(2)))
    assert sorted(codes)==[200,400]
    assert all('token_hash' not in r for r in api.get('/v1/admin/invitations',headers=headers(owner)).json()['items'])
def test_roles_recovery_and_revoked_sessions(api):
    owner=admin(api);user=invited(api,owner)
    assert not api.get('/v1/me',headers=headers(user)).json()['admin']
    assert api.get('/v1/admin/users',headers=headers(user)).status_code==403
    assert api.get('/v1/books?q=sabio',headers=headers(user)).status_code==200
    assert api.post('/v1/books',headers=headers(user)).status_code==401
    code=api.post('/v1/admin/users/'+user['user']['id']+'/recovery',headers=headers(owner)).json()['code']
    body=dict(code=code,password='new-password-123456')
    fresh=api.post('/v1/auth/reset-password',json=body);assert fresh.status_code==200
    assert api.get('/v1/me',headers=headers(user)).status_code==401
    assert api.post('/v1/auth/reset-password',json=body).status_code==400
    assert api.post('/v1/auth/logout',headers=headers(fresh.json())).status_code==200
    assert api.get('/v1/me',headers=headers(fresh.json())).status_code==401

def test_private_libraries_merge_archive_and_backup(api):
    owner=admin(api);a=invited(api,owner);b=invited(api,owner)
    data=snapshot();identifier=str(uuid.uuid4())
    assert result(sync(api,a,data,request_id=identifier))['revision']==1
    assert result(sync(api,a,data,request_id=identifier))['revision']==1
    reused=copy.deepcopy(data);reused['library']['books'][0]['title']='Alterado'
    assert sync(api,a,reused,request_id=identifier).status_code==409
    assert api.get('/v1/me/library',headers=headers(b)).status_code==404
    assert api.get('/v1/me/library',headers=AUTH).status_code==401
    server=copy.deepcopy(data);server['library']['books'][0]['rating']=4.5
    result(sync(api,a,server,1));phone=copy.deepcopy(data);phone['library']['books'][0]['currentPage']=25
    merged=result(sync(api,a,phone,1));book=merged['snapshot']['library']['books'][0];assert book['rating']==4.5 and book['currentPage']==25
    book['archived']=True;result(sync(api,a,merged['snapshot'],3))
    older=api.get('/v1/me/library?revision=1',headers=headers(a));assert json.loads(gzip.decompress(older.content))['library']['books'][0]['rating'] is None
    assert api.get('/v1/me/library/status',headers=headers(b)).json()['revision']==0

def test_same_field_conflict_is_explicit_and_revision_bound(api):
    a=invited(api,admin(api));original=snapshot();result(sync(api,a,original))
    server=copy.deepcopy(original);server['library']['books'][0]['currentPage']=30;result(sync(api,a,server,1))
    phone=copy.deepcopy(original);phone['library']['books'][0]['currentPage']=50
    conflict=sync(api,a,phone,1);assert conflict.status_code==409
    detail=conflict.json()['detail'];path=detail['conflicts'][0]['path'];assert path.endswith('/currentPage')
    assert sync(api,a,phone,1,resolutions={path:'local'},against_revision=1).status_code==409
    assert result(sync(api,a,phone,1,resolutions={path:'local'},against_revision=2))['snapshot']['library']['books'][0]['currentPage']==50

def test_validation_throttle_and_revoked_invitation(api):
    owner=admin(api);a=invited(api,owner);bad=snapshot();bad['library']['books'][0]['currentPage']=101
    assert sync(api,a,bad).status_code==422
    bad=snapshot();bad['appearance']['SERVER_TOKEN']='secret';assert sync(api,a,bad).status_code==422
    bad=snapshot();bad['appearance']['BOOK_SECRET']='secret';assert sync(api,a,bad).status_code==422
    invite=api.post('/v1/admin/invitations',headers=headers(owner),json={}).json();api.delete('/v1/admin/invitations/'+invite['id'],headers=headers(owner))
    assert api.post('/v1/auth/register',json=dict(email='revoked@example.test',password='password-123456',invitation=invite['code'])).status_code==400
    email=uuid.uuid4().hex+'@example.test'
    statuses=[api.post('/v1/auth/login',json=dict(email=email,password='wrong-password-123456')).status_code for _ in range(13)]
    assert statuses[:12]==[401]*12 and statuses[-1]==429

def test_retention_compact_bases_and_automatic_stale_rejection(api):
    a=invited(api,admin(api));original=snapshot();result(sync(api,a,original));local=copy.deepcopy(original);local['library']['books'][0]['author']='Outro'
    for base in range(1,13):
        data=copy.deepcopy(original);data['library']['books'][0]['currentPage']=base
        result(sync(api,a,data,base))
    assert sync(api,a,local,1,strict_base=True).status_code==409
    final=result(sync(api,a,local,1));assert final['snapshot']['library']['books'][0]['currentPage']==12
    status=api.get('/v1/me/library/status',headers=headers(a)).json();assert len(status['versions'])==10
    assert api.get('/v1/me/library?revision=1',headers=headers(a)).status_code==404

def test_archived_flag_merges_with_progress_from_offline_device():
    original=snapshot();local=copy.deepcopy(original);server=copy.deepcopy(original)
    server['library']['books'][0]['archived']=True;local['library']['books'][0]['currentPage']=12
    merged,conflicts=merge_snapshot(original,local,server)
    assert not conflicts and merged['library']['books'][0]['archived'] and merged['library']['books'][0]['currentPage']==12

def test_compact_cover_bases_merge_without_image_loss():
    original=snapshot();original['library']['books'][0]['coverData']='data:image/jpeg;base64,old'
    local=copy.deepcopy(original);local['library']['books'][0]['title']='Nome pessoal'
    server=copy.deepcopy(original);server['library']['books'][0]['coverData']='data:image/jpeg;base64,new'
    merged,conflicts=merge_snapshot(compact(original),local,server)
    assert not conflicts and merged['library']['books'][0]['coverData'].endswith(',new') and merged['library']['books'][0]['title']=='Nome pessoal'

def test_duplicate_reading_day_is_a_set():
    original=snapshot();local=copy.deepcopy(original);server=copy.deepcopy(original)
    local['library']['readingDates']=[dict(id='a',bookId='book',day='2026-10-17')];server['library']['readingDates']=[dict(id='b',bookId='book',day='2026-10-17')]
    merged,conflicts=merge_snapshot(original,local,server)
    assert not conflicts and len(merged['library']['readingDates'])==1
