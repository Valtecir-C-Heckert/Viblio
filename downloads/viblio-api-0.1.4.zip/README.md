# API do novo Viblio

Backend independente em Python/FastAPI para o APK. Usa exclusivamente `public.valteca` no PostgreSQL 17 informado. Não usa o Valteca antigo, Supabase, Next.js, contas antigas ou serviços pagos. A biblioteca pessoal, progresso, notas, histórico e volumes continuam no SQLite do aparelho. Não é necessário criar/migrar `biblioteca_usuario` nesta etapa.

## Instalar no Debian, ao lado do PostgreSQL existente

Extraia este pacote em **`/opt/viblio/api`**, sem substituir `/opt/viblio/compose.yaml`. Use a rede existente `viblio_default` e o host interno `postgres`. O Compose deste pacote cria somente a API e seu volume de capas.

```bash
cd /opt/viblio/api
# Backup antes das migrações; o arquivo fica no seu servidor.
docker exec viblio-postgres pg_dump -U viblio -d viblio -Fc > viblio-before-api.dump
# SQL aditivo: novos IDs e índices, sem reescrever os 131 mil livros.
docker exec -i viblio-postgres psql -v ON_ERROR_STOP=1 -U viblio -d viblio < migrations/001_api.sql
docker exec -i viblio-postgres psql -v ON_ERROR_STOP=1 -U viblio -d viblio < migrations/002_search.sql
python3 scripts/configure.py
docker compose -p viblio-catalog-api -f compose.api.yaml up -d --build
docker compose -p viblio-catalog-api -f compose.api.yaml ps
```

O configurador pede o endereço que o celular alcança e a senha do PostgreSQL somente no seu terminal. Gera uma chave aleatória e grava `.env` com permissão 600. Abra esse arquivo **localmente** e copie somente `VIBLIO_API_TOKEN` para o APK. Não publique/envie `.env`, senha ou chave. Se a senha original foi definida em `/opt/viblio/compose.yaml` ou no `.env` antigo do PostgreSQL, consulte-a localmente; este pacote não muda essa senha.

A API usa a porta 8088 por padrão. Ajuste `VIBLIO_API_PORT` se necessário e use o mesmo endereço em `PUBLIC_BASE_URL` e no APK. `VIBLIO_BIND_ADDRESS` permite limitar o bind a uma interface. Use na rede local/Tailscale; para endereço público, configure HTTPS. O APK aceita HTTP apenas para IPs privados, localhost, `.local` e `.ts.net`; não encaminha a chave a sites externos ou redirecionamentos.

No Viblio: **Estante → ⋮ → Backup / importar → Catálogo do servidor**, ou **Adicionar livro → Conectar catálogo**. Informe o endereço e a chave. Android 6+ para guardar a chave no Keystore; Android 5 mantém toda a biblioteca e o cadastro local.

## Fluxo e contrato

- `GET /v1/health`: autenticado; verifica banco/tabela auxiliar e retorna identidade persistente do catálogo.
- `GET /v1/books?q=...&author=...&isbn=...&limit=20&cursor=...`: autenticado; busca parcial literal, acentos/caixa normalizados, limite máximo 50, paginação por ID. IDs bigint são enviados como string, inclusive acima de 2^53.
- `POST /v1/books`: autenticado; multipart com `metadata` JSON e `cover` opcional. Campos aceitos: `request_id`, `catalog_id`, `title`, `author`, `genre`, `subgenres`, `publisher`, `saga`, `sequence`, `pages`, `isbn`. `request_id` UUID torna a repetição idempotente. Não recebe progresso/notas pessoais.
- `GET /covers/<uuid-sem-hifens>.jpg`: acesso à imagem por nome aleatório, sem credencial na URL. Não lista o volume e recusa nomes/caminhos arbitrários.

Selecionar uma sugestão preenche somente o que a API conhece. `metricas_totais` vira páginas apenas quando `metrica_tipo` indica páginas; volumes/minutos não são convertidos. `ordem` é preenchida apenas se inteira e positiva. Campos ausentes continuam vazios. Nenhum ISBN ou dado fictício é inventado. O formulário atual exige páginas para livros comuns e as pede se não estiverem no catálogo.

Capas externas são carregadas diretamente no APK e guardadas no cache de imagens atual. Uma escolha manual tem prioridade. Não há busca/download em massa pelo servidor. Capas manuais são enviadas, validadas por conteúdo, limitadas a 12 MB/20 milhões de pixels, convertidas em JPEG e gravadas em volume persistente com nome UUID. O PostgreSQL guarda URL/referência, nunca Base64. O backup JSON do aparelho continua portátil com capas embutidas; isso não é armazenamento de imagem no banco do servidor.

Livro novo sem vínculo: criar/resolver registro e retornar ID. Duplicação é evitada sob transação/lock por ISBN normalizado, ou correspondência exata de título/autor/editora quando não há ISBN, respeitando páginas e número quando ambos são conhecidos; correspondências parciais servem apenas para sugestões. ISBNs diferentes podem ser edições diferentes. Catálogo existente com edição pessoal/capa manual não é sobrescrito: a capa local e sua cópia enviada são preservadas sem alterar a capa pública do registro original.

Biblioteca e cadastro manual continuam disponíveis sem conexão. A fila de envio fica persistida no aparelho, e pode ser reenviada em Catálogo do servidor. A resposta atualiza apenas o vínculo, preservando identificador local, histórico e páginas. O vínculo vai no backup JSON como campos opcionais da versão 5; leitores anteriores ignoram esses campos, preservando os demais dados. A chave não entra no backup.

## Armazenamento e manutenção

Volume `viblio-catalog-api_viblio-covers`: inclui capas e identidade estável `catalog-id`. Preserve-o junto do dump PostgreSQL; não use `docker compose down -v`. A identidade impede associar IDs iguais de catálogos diferentes. Não substitua o volume ao atualizar. `.env` guarda configuração e chave; não é incluído no ZIP ou na imagem.

As migrações criam extensões `unaccent`/`pg_trgm`, função normalizada, sequência/default para os novos IDs e tabelas auxiliares de idempotência/capas. Os índices de busca são construídos CONCURRENTLY. As migrações podem ser repetidas; se `id` já tiver um default diferente, a primeira para para revisão. Alterar o dicionário unaccent posteriormente exige reconstruir os índices normalizados.

A API roda sem root, sem capabilities adicionais e com autenticação Bearer de uma instalação pessoal. Não é um sistema de contas múltiplas. Mudanças pessoais não são sincronizadas entre aparelhos nesta edição. Uma falha entre gravar arquivo e confirmar a transação pode deixar um arquivo órfão; nenhuma rotina de limpeza/migração de imagens em massa é executada.

## Desenvolvimento e testes

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/pip install pytest httpx
VIBLIO_TEST_PYTHON=.venv/bin/python scripts/test-api.sh
```

O script inicia um PostgreSQL 17 isolado com credenciais temporárias e apaga somente esse contêiner ao terminar. Os testes recusam banco que não comece com `viblio_test`; não os rode contra seu catálogo pessoal. Testa esquema real, migrações repetidas, busca, concorrência, nulos, IDs grandes, upload, isolamento de escolhas pessoais e autenticação.

O pacote ZIP inclui wheels verificadas para Linux x86_64/Python 3.12. Nesse servidor o configurador ativa OFFLINE_WHEELS=1, permitindo instalar dependências sem consultar o PyPI durante o build. O repositório de fontes usa instalação online por padrão; para outros processadores mantenha OFFLINE_WHEELS=0. A imagem base Python ainda precisa estar disponível no Docker.
